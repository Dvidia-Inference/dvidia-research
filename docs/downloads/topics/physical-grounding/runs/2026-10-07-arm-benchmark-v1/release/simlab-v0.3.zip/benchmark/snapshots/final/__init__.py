"""Isolated arm benchmark snapshot."""
