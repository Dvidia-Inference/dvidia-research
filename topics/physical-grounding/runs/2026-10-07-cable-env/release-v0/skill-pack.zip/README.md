# DVIDIA simulation-only skill pack

Task: CableEndReach-v0. Actuation: ideal Cartesian force attachment at the cable tip. Observations: privileged simulator state. No physical robot or sensor qualification.

Verify this archive with `python -m simlab verify-pack skill-pack.zip`. After inspecting and unpacking it, create a Python 3.12 environment, install `requirements.lock.txt`, and use `PYTHONPATH=code python -m simlab run --config run.json --policy-file policy.json --seeds 100,101,102 --output replay`. Dependencies must be staged separately for an air-gapped installation.
