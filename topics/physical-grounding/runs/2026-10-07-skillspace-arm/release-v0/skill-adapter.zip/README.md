# DVIDIA articulated-arm simulation adapter

This is an authored simulation controller bound to DVIDIA task metadata. No physical robot qualification or learned video policy is included.

Use Python 3.12+ and the pinned dependencies in requirements.lock.txt. From this extracted directory: `python -m simlab.studio --offline` for the local lab, or `python -m simlab.arm_qualify --source evidence/source.json --output reproduced` to repeat the six-layout protocol. If source has no inline grounding, arm_qualify explicitly binds the documented local adapter. Dependencies must already be installed for offline execution.

Hashes check content integrity, not publisher identity or authenticity. See evidence/run.json for exact task, scene, contact exclusions, timings and outcomes.
